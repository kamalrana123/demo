from django.shortcuts import render
from django.http import HttpResponse,HttpResponseRedirect
from .models import Destination
# Create your views here.


def index(request):

    dests=Destination.objects.all()
    return render(request,"index.html",{'dests':dests})

def home(request):
    return render(request,"home.html")

def show(request):
    dests=Destination.objects.all()
    return render(request,"show.html",{'dests':dests})

def send(request):
    if request.method=='POST':
        id=request.POST['id']
        name=request.POST['name']
        pdf=request.POST['pdf']
        Destination(id=id,name=name,pdf=pdf).save()
        msg="data store successfully"
        return render(request,"home.html",{'msg':msg})
    else:
        return HttpResponse("<h1> 404 - not found </h1>")

def delete(request):
    id=request.GET['id']
    Destination.objects.filter(id=id).delete()
    return HttpResponseRedirect("show")

def edit(request):
    id=request.GET['id']
    name=pdf="not_available"
    for dests in Destination.objects.filter(id=id):
        name=dests.name
        pdf=dests.pdf

    return render(request,"edit.html",{'id':id,'name':name,'pdf':pdf})

def RecordEdited(request):
    if request.method=='POST':
        id=request.POST['id']
        name=request.POST['name']
        pdf=request.POST['pdf']
        Destination.objects.filter(id=id).update(name=name,pdf=pdf)
        return HttpResponseRedirect("show")
    else:
        return HttpResponse("<h1>404 : Not Found </h1>")

