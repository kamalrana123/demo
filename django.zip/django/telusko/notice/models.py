from django.db import models



# Create your models here.
class Destination(models.Model):
    name=models.CharField(max_length=100)
    id=models.AutoField(primary_key=True)
    pdf=models.FileField(upload_to='assets')

    