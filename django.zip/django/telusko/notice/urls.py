from django.urls import path
from . import views




urlpatterns=[
    path("",views.index,name="index"),
    path("home",views.home),
    path("show",views.show),
    path("send",views.send),
    path("delete",views.delete),
    path("edit",views.edit),
    path('RecordEdited',views.RecordEdited)
    ]